<?php


require_once "routeSwitch.php";

class Router extends RouteSwitch{

    public function run( string $requestUri ){

        // echo $requestUri;
        // die();

        $route = substr($requestUri, 1);
        
        if($route === "api_send_email/"){

            $this->api_function();

        }else{
            $this->$route();
        }

    }

}