<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require "PHPMailer/vendor/autoload.php";

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8; multipart/form-data");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// echo ($_POST['email']); die();

if($_POST){
    send_email($_POST['nome'], $_POST['email'], $_POST['assunto'], $_POST['mensagem']);
}else{
    message_reponse('Erro', 405, 'Requisição inválida.'); //405 -> Método inválido
}

function send_email($user_name, $user_email, $message_subject, $message_body){

    if($user_name && $user_email && $message_subject && $message_body){

        // if(filter_var($user_email, FILTER_VALIDATE_EMAIL)){

            $client_user_email = "geralsaude@cimed.ao";

            $mail = new PHPMailer();
            $mail->CharSet = 'UTF-8';
            
            $mail->isSMTP();
            $mail->Host = 'mail.cimed.ao';
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = 'tls';
            $mail->Username = $client_user_email;
            $mail->Password = 'cimed_suporte.2022';
            $mail->Port = 587;
            
            $mail->setFrom($user_email, $user_name);
            $mail->addReplyTo($user_email);
            $mail->addCC('geraladm@cimed.ao');
            $mail->addAddress($client_user_email);
    
            $mail->isHTML(true);
            $mail->Subject = ($message_subject);
            $mail->Body    = ($message_body."<br><br><strong>Mensagem enviada apartir do website da CIMED</strong>");
            // $mail->AltBody = 'Para visualizar essa mensagem acesse';
    
    
            if(!$mail->send()) {

                message_reponse('Erro', 500,'Erro ao enviar esta mensagem. Tente novamente ou contacte o proprietário.'); //500 -> Erro no servidor interno

            } else {

                message_reponse('Sucesso', 200, 'Mensagem enviada com êxito!'); //200 -> OK

            }
            
        // }else{
        //     message_reponse('Erro', 401, 'Email inválido!'); //401 -> Não autorizado
        // }
    }else{
        message_reponse('Erro', 400, 'Requisição inválida!'); //400 -> Má requisição
    }

}

function message_reponse(string $status = '', int $code = 0, string $message = ''){
    
    // http_response_code($code);

    $response_array = [
        'estado' => $status,
        'mensagem' => $message
    ];
    echo json_encode($response_array);
}